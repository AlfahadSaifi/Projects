package org.nucleus.entity;

import lombok.Data;

import javax.persistence.*;

@Data
@Entity
@Table(name = "TAG")
@Inheritance(strategy = InheritanceType.JOINED)
public class Tag {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    private Form form;
    private boolean isRequired;
    private String type;
    private String name;
    private String label;
}