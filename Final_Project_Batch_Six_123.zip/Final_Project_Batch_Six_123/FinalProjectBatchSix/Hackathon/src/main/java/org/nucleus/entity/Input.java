package org.nucleus.entity;

import lombok.Data;
import lombok.EqualsAndHashCode;

import javax.persistence.Entity;
import javax.persistence.Table;


@EqualsAndHashCode(callSuper = false)
@Data
@Entity
@Table(name = "INPUT")
public class Input extends Tag {
    private Integer maxLength;
    private Integer maxValue;
    private Integer minValue;
}