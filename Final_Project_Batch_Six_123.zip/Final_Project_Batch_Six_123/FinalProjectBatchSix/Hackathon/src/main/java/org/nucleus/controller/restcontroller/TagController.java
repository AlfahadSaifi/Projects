package org.nucleus.controller.restcontroller;

import org.nucleus.entity.Tag;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import javax.ws.rs.core.MediaType;
import java.util.List;

@RestController
public class TagController {
    @PostMapping(value = "/tags", consumes = MediaType.APPLICATION_JSON)
    public void handleVehicles(@RequestBody List<Tag> tags) {

        for (Tag tag : tags) {
            System.out.println(tag);
            if ("INPUT".equalsIgnoreCase(tag.getType())) {
                // Process car object
                System.out.println(tag);
            }
        }
    }
}