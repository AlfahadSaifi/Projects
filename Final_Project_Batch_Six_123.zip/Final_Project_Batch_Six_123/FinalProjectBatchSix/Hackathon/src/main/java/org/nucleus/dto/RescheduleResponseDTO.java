package org.nucleus.dto;

import lombok.Data;

@Data
public class RescheduleResponseDTO {
    private String productCode;
    private String effectiveDate;
    private String currentDueDate;
    private String currentInstallment;
    private String currentTenure;
    private String frequency;
    private String rate;
}
