package org.nucleus.entity;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.Entity;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import java.util.List;

@Getter
@Setter
@Entity
@Table(name = "DROPDOWN")
public class Dropdown extends Tag {
    @OneToMany(mappedBy = "dropdown")
    private List<DropdownValues> values;
}