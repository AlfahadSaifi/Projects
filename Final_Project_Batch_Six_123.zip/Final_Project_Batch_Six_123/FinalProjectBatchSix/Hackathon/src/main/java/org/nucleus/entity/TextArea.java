package org.nucleus.entity;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.Entity;
import javax.persistence.Table;

@Getter
@Setter
@Entity
@Table(name = "TEXTAREA")
public class TextArea extends Tag{
    private Integer maxLength;
}