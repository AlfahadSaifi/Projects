package org.nucleus.utility.enums;

public enum ClosureStatus {
    EARLY_CLOSURE,
    REGULAR_CLOSURE
}
