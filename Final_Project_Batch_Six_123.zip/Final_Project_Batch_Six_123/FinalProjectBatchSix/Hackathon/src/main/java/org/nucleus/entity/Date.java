package org.nucleus.entity;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.Entity;
import javax.persistence.Table;

@Getter
@Setter
@Entity
@Table(name = "DATE")
public class Date extends Tag{
    private boolean isPast;
    private boolean isPresent;
    private boolean isFuture;
}