package org.nucleus.entity;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.Entity;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import java.util.List;

@Getter
@Setter
@Entity
@Table(name = "RADIO")
public class Radio extends Tag {
    @OneToMany(mappedBy = "radio")
    private List<RadioValues> values;
}