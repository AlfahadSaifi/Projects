package org.nucleus.dao;

import org.nucleus.entity.Form;
import org.springframework.data.jpa.repository.JpaRepository;

public interface FormDao extends JpaRepository<Form, Long> {
}
