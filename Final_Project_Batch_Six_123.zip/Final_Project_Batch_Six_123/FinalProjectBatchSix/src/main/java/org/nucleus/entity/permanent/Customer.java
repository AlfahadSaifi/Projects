package org.nucleus.entity.permanent;

import lombok.Data;
import org.nucleus.entity.meta.MetaData;

import javax.persistence.*;
import java.util.List;

@Data
@Entity
@Table(name = "CUSTOMER_TBL_BATCH_6")
@TableGenerator(name="ID_TABLE_GEN_BATCH_6",pkColumnValue = "CUSTOMER_TBL_BATCH_6",initialValue=100000, allocationSize=1)
public class Customer {
    @Id
    @GeneratedValue(strategy= GenerationType.TABLE, generator="ID_TABLE_GEN_BATCH_6")
    private Long customerId;

    private String cifNumber;
    private Long contactNumber;
    private String emailAddress;

    @OneToOne(mappedBy = "customer")
    private PersonInfo personInfo;

    @OneToOne(mappedBy = "customer")
    private OccupationInfo occupationInfo;

    @OneToOne(mappedBy = "customer")
    private FinancialInfo financialInfo;

    @OneToOne
    private Address address;

    @OneToMany(mappedBy = "customer")
    private List<LoanApplication> loans;
    @Embedded
    private MetaData metaData;
}