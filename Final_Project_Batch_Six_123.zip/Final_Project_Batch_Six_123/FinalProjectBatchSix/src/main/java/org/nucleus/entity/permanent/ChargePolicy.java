package org.nucleus.entity.permanent;

import lombok.Data;
import org.nucleus.entity.meta.MetaData;

import javax.persistence.*;
import java.util.List;

@Data
@Entity
@Table(name = "CHARGE_POLICY_TBL_BATCH_6")
@TableGenerator(name="ID_TABLE_GEN_BATCH_6",pkColumnValue = "CHARGE_POLICY_TBL_BATCH_6",initialValue=100000, allocationSize=1)
public class ChargePolicy {
    @Id
    @GeneratedValue(strategy= GenerationType.TABLE, generator="ID_TABLE_GEN_BATCH_6")
    private Long policyId;
    private String policyCode;
    private String policyName;

    @OneToMany
    private List<ChargePolicyParameter> chargePolicyParameterList;
    @Embedded
    private MetaData metaData;
}
