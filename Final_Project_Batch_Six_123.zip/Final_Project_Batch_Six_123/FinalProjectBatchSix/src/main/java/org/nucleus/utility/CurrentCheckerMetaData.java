package org.nucleus.utility;

import org.nucleus.entity.meta.MetaData;
import org.nucleus.entity.meta.TempMetaData;
import org.nucleus.utility.enums.RecordStatus;

public class CurrentCheckerMetaData {

    public static MetaData getMetaDataForApprovedCreation(MetaData metaData){
        metaData.setRecordStatus(RecordStatus.A);

//        metaData.setModifiedDate();
//        metaData.setModifiedBy();

        return metaData;
    }

    public static MetaData getMetaDataForApprovedModification(MetaData metaData){
        metaData.setRecordStatus(RecordStatus.A);

//        metaData.setModifiedDate();
//        metaData.setModifiedBy();

        return metaData;
    }

}
