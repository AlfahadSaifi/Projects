package org.nucleus.entity.permanent;

import lombok.Data;
import org.nucleus.entity.meta.MetaData;
import org.nucleus.utility.enums.LoanSecurityType;

import javax.persistence.*;

@Data
@Entity
@Table(name = "LOAN_PRODUCT_TBL_BATCH_6")
@TableGenerator(name="ID_TABLE_GEN_BATCH_6",pkColumnValue = "LOAN_PRODUCT_TBL_BATCH_6",initialValue=100000, allocationSize=1)
public class LoanProduct {
    @Id
    @GeneratedValue(strategy= GenerationType.TABLE, generator="ID_TABLE_GEN_BATCH_6")
    private Long productId;

    private String productCode;
    private String productName;
    private String productDescription;
    private LoanSecurityType securityType;
    private Double rateOfInterest;

    @ManyToOne
    private ProductType productType;

    @ManyToOne
    private EligibilityPolicy eligibilityPolicy;

    @ManyToOne
    private RepaymentPolicy repaymentPolicy;

    @ManyToOne
    private ChargePolicy chargePolicy;

    @Embedded
    private MetaData metaData;
}