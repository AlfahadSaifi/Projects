package org.nucleus.entity.temporary;

import lombok.Data;
import org.nucleus.entity.meta.MetaData;
import org.nucleus.entity.meta.TempMetaData;

import javax.persistence.*;

@Data
@Entity
@Table(name = "ADDRESS_TEMP_TBL_BATCH_6")
@TableGenerator(name="ID_TEMP_TABLE_GEN_BATCH_6",pkColumnValue = "ADDRESS_TEMP_TBL_BATCH_6",initialValue=100000, allocationSize=1)
public class AddressTemp {
    @Id
    @GeneratedValue(strategy= GenerationType.TABLE, generator="ID_TEMP_TABLE_GEN_BATCH_6")
    private Integer addressId;
    private String addressType;
    private String fullAddress;
    @OneToOne
    private CountryTemp country;
    @OneToOne
    private StateTemp state;
    @OneToOne
    private CityTemp city;
    private String flatNumber;
    private Integer pinCode;
    private String region;
    private String district;
    @Embedded
    private TempMetaData metaData;
}