package org.nucleus.utility.enums;

public enum RepaymentFrequency {
    MONTHLY , YEARLY , HALF_YEARLY , QUARTERLY
}
