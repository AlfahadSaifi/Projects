package org.nucleus.entity.temporary;

import lombok.Data;
import org.nucleus.entity.meta.MetaData;
import org.nucleus.entity.meta.TempMetaData;
import org.nucleus.utility.enums.ClosureStatus;

import javax.persistence.*;
import java.util.Date;

@Data
@Entity
@Table(name = "LOAN_CLOSURE_TEMP_TBL_BATCH_6")
@TableGenerator(name="ID_TEMP_TABLE_GEN_BATCH_6",pkColumnValue = "LOAN_CLOSURE_TEMP_TBL_BATCH_6",initialValue=100000, allocationSize=1)
public class LoanClosureTemp {
    @Id
    @GeneratedValue(strategy= GenerationType.TABLE, generator="ID_TEMP_TABLE_GEN_BATCH_6")
    private Long loanClosureId;

    @OneToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "loanId")
    private LoanAccountTemp loanAccount;

    private Date loanClosureDate;

    @Enumerated(EnumType.STRING)
    private ClosureStatus closureStatus;

    @Embedded
    private TempMetaData metaData;
}