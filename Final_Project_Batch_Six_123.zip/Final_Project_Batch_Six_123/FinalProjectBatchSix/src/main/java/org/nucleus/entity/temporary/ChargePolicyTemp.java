package org.nucleus.entity.temporary;

import lombok.Data;
import org.nucleus.entity.meta.MetaData;
import org.nucleus.entity.meta.TempMetaData;

import javax.persistence.*;
import java.util.List;

@Data
@Entity
@Table(name = "CHARGE_POLICY_TEMP_TBL_BATCH_6")
@TableGenerator(name="ID_TEMP_TABLE_GEN_BATCH_6",pkColumnValue = "CHARGE_POLICY_TEMP_TBL_BATCH_6",initialValue=100000, allocationSize=1)
public class ChargePolicyTemp {
    @Id
    @GeneratedValue(strategy= GenerationType.TABLE, generator="ID_TEMP_TABLE_GEN_BATCH_6")
    private Long policyId;
    private String policyCode;
    private String policyName;

    @OneToMany
    private List<ChargePolicyParameterTemp> chargePolicyParameterList;

    @Embedded
    private TempMetaData metaData;
}
