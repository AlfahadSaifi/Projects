package org.nucleus.utility.enums;

public enum Operator {
    EQUALSTO
}
