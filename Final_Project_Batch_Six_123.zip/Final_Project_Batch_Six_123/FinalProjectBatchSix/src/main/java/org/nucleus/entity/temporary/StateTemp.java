package org.nucleus.entity.temporary;

import lombok.Data;
import org.nucleus.entity.meta.MetaData;
import org.nucleus.entity.meta.TempMetaData;

import javax.persistence.*;
import java.util.ArrayList;
import java.util.List;

@Data
@Entity
@Table(name = "STATE_TEMP_TBL_BATCH_6")
@TableGenerator(name="ID_TEMP_TABLE_GEN_BATCH_6",pkColumnValue = "STATE_TEMP_TBL_BATCH_6",initialValue=100000, allocationSize=1)
public class StateTemp {
    @Id
    @GeneratedValue(strategy= GenerationType.TABLE, generator="ID_TEMP_TABLE_GEN_BATCH_6")
    private Integer id;

    private String stateCode;
    private String stateName;

    @ManyToOne
    @JoinColumn(name = "country_id")
    private CountryTemp country;

    private String region;
    private Boolean isUnionTerritory;

    @OneToMany(mappedBy = "state", cascade = CascadeType.ALL, fetch = FetchType.EAGER)
    private List<CityTemp> cities;

    @Embedded
    private TempMetaData metaData;

    public StateTemp() {
        this.cities = new ArrayList<>();
    }
}
