package org.nucleus.utility.enums;

public enum ReceiptBasis {
    SINGLE_ACCOUNT
}
