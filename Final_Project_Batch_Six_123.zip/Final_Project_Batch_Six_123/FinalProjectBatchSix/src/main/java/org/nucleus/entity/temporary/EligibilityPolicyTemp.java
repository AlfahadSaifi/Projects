package org.nucleus.entity.temporary;

import lombok.Data;
import org.nucleus.entity.meta.MetaData;
import org.nucleus.entity.meta.TempMetaData;
import org.nucleus.entity.permanent.EligibilityPolicyParameter;

import javax.persistence.*;
import java.util.List;

@Data
@Entity
@Table(name = "ELIGIBILITY_POLICY_TEMP_TBL_BATCH_6")
public class EligibilityPolicyTemp {
    @Id
    private String eligibilityPolicyCode;
    private String eligibilityCriteria;

    @OneToMany(cascade = CascadeType.ALL)
    @JoinColumn(name = "eligibilityPolicyParameterId")
    private List<EligibilityPolicyParameter> eligibilityParameterMappingList;
    @Embedded
    private MetaData metaData;
}