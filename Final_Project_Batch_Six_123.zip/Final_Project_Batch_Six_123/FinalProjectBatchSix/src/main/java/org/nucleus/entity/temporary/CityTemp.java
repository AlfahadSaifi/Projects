package org.nucleus.entity.temporary;

import lombok.Data;
import org.nucleus.entity.meta.MetaData;
import org.nucleus.entity.meta.TempMetaData;

import javax.persistence.*;

@Data
@Entity
@Table(name = "CITY_TEMP_TBL_BATCH_6")
@TableGenerator(name="ID_TEMP_TABLE_GEN_BATCH_6",pkColumnValue = "CITY_TEMP_TBL_BATCH_6",initialValue=100000, allocationSize=1)
public class CityTemp {
    @Id
    @GeneratedValue(strategy= GenerationType.TABLE, generator="ID_TEMP_TABLE_GEN_BATCH_6")
    private Integer id;

    private String country;

    @ManyToOne
    @JoinColumn(name = "state_id")
    private StateTemp state;

    private String district;
    private String cityName;
    private String cityCode;
    private String stdCode;
    private String cityMICRCode;
    private String locationType;
    private String cityCategorization;
    private String cityRiskCategory;

    @Embedded
    private TempMetaData metaData;
}
