package org.nucleus.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/reschedule")
public class RescheduleController {

    @GetMapping
    public String showReschedulePage(){
        return "reschedule";
    }

}
