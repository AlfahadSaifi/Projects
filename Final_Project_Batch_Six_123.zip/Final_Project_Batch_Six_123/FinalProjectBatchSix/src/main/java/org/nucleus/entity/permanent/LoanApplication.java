package org.nucleus.entity.permanent;

import lombok.Data;
import org.nucleus.entity.meta.MetaData;

import javax.persistence.*;
import java.sql.Date;

@Data
@Entity
@Table(name = "LOAN_APPLICATION_TBL_BATCH_6")
@TableGenerator(name="ID_TABLE_GEN_BATCH_6",pkColumnValue = "LOAN_APPLICATION_TBL_BATCH_6",initialValue=100000, allocationSize=1)
public class LoanApplication {
    @Id
    @GeneratedValue(strategy= GenerationType.TABLE, generator="ID_TABLE_GEN_BATCH_6")
    private Long loanApplicationId;
    private Date applicationCreationDate;
    private Double loanAmount;
    private Integer tenure;
    private String loanAccountNumber;
    @OneToOne
    private LoanProduct loanProduct;
    @ManyToOne
    private Customer customer;
    @Embedded
    private MetaData metaData;
}