package org.nucleus.entity.temporary;

import lombok.Data;
import org.nucleus.entity.meta.MetaData;
import org.nucleus.entity.meta.TempMetaData;

import javax.persistence.*;
import java.util.List;

@Data
@Entity
@Table(name = "CUSTOMER_TEMP_TBL_BATCH_6")
@TableGenerator(name="ID_TEMP_TABLE_GEN_BATCH_6",pkColumnValue = "CUSTOMER_TEMP_TBL_BATCH_6",initialValue=100000, allocationSize=1)
public class CustomerTemp {
    @Id
    @GeneratedValue(strategy= GenerationType.TABLE, generator="ID_TEMP_TABLE_GEN_BATCH_6")
    private Long customerId;

    private String cifNumber;
    private Long contactNumber;
    private String emailAddress;

    @OneToOne(mappedBy = "customer")
    private PersonInfoTemp personInfo;

    @OneToOne(mappedBy = "customer")
    private OccupationInfoTemp occupationInfo;

    @OneToOne(mappedBy = "customer")
    private FinancialInfoTemp financialInfo;

    @OneToOne
    private AddressTemp address;

    @OneToMany(mappedBy = "customer")
    private List<LoanApplicationTemp> loans;

    @Embedded
    private TempMetaData metaData;
}