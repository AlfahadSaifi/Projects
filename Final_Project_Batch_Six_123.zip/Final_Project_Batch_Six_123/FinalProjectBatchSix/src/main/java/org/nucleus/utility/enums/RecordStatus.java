package org.nucleus.utility.enums;

public enum RecordStatus {
    N, M, D, NR, MR, DR, A, R
}
