package org.nucleus.controller.restcontroller;

import org.nucleus.dto.RescheduleResponseDTO;
import org.nucleus.entity.temporary.RepayScheduleTemp;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.sql.Date;
import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping("/reschedule")
public class RescheduleRestController {
    @GetMapping("/getCustomerNameByLoanAccountNumber")
    public ResponseEntity<String> getCustomerNameByLoanAccountNumber(@RequestParam String loanAccountNumber) {
        String customerName = "Ayush";
        // logic
        return ResponseEntity.status(HttpStatus.OK).body(customerName);
    }
    @GetMapping("/getRescheduleResponse")
    public ResponseEntity<RescheduleResponseDTO> getRescheduleResponse(@RequestParam String loanAccountNumber) {
        // Perform your search logic here
        RescheduleResponseDTO response = new RescheduleResponseDTO();
        // Fill response with data to autofill form fields
        response.setProductCode("ABC123");
        response.setEffectiveDate("2024-05-01");
        response.setCurrentDueDate("23");
        response.setCurrentInstallment("$1000");
        response.setCurrentTenure("12");
        response.setFrequency("Monthly");
        response.setRate("5%");
        return ResponseEntity.status(HttpStatus.OK).body(response);
    }
    @GetMapping("/checkRepaySchedule")
    public ResponseEntity<List<RepayScheduleTemp>> checkRepaySchedule(@RequestParam String key, @RequestParam String value) {
        // Perform your search logic here
        List<RepayScheduleTemp> repaySchedule = new ArrayList<>();
        // Fill response with data to autofill form fields
        for (int i = 0; i < 20; i++) {
            RepayScheduleTemp schedule = new RepayScheduleTemp();
            schedule.setId((long) (i + 1)); // Setting ID
            schedule.setEffectiveInterestRate(5.0); // Setting effective interest rate
            schedule.setInstallmentAmount(100.0); // Setting installment amount
            schedule.setInstallmentNumber(i + 1); // Setting installment number
//            LoanAccount loanAccount = new LoanAccount();
//            loanAccount.setLoanAccountNumber("XXXX1234");
//            schedule.setLoanAccount(loanAccount); // Setting setLoanAccountNumber
            schedule.setLoanApplicationId(" "+(i + 2001)); // Setting loan application ID
            schedule.setOpeningBalance(1000.0); // Setting opening balance
            schedule.setOutstandingBalancePrincipal(900.0); // Setting outstanding balance principal
            schedule.setPrincipalComponent(90.0); // Setting principal component
            schedule.setDueDate(Date.valueOf("2001-01-01")); // Setting due date
            schedule.setInterestComponent(10.0); // Setting interest component
            repaySchedule.add(schedule); // Adding the RepaySchedule object to the list
        }


        return ResponseEntity.status(HttpStatus.OK).body(repaySchedule);
    }

}
