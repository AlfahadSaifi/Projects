package basePackage.entity;

import basePackage.utility.enums;

import javax.persistence.*;


@Entity
@Table(name = "repaymentpolicymaster_tbl_17241")
public class RepaymentPolicy {

    @Id
    private long repaymentPolicyId;
    private String repaymentPolicyCode;
    private String repaymentPolicyName;

    @Enumerated(EnumType.STRING)
    private enums.RepaymentType repaymentType;

    @Enumerated(EnumType.STRING)
    private enums.RepaymentFrequency repaymentFrequency;

    public long getRepaymentPolicyId() {
        return repaymentPolicyId;
    }

    public void setRepaymentPolicyId(long repaymentPolicyId) {
        this.repaymentPolicyId = repaymentPolicyId;
    }

    public String getRepaymentPolicyCode() {
        return repaymentPolicyCode;
    }

    public void setRepaymentPolicyCode(String repaymentPolicyCode) {
        this.repaymentPolicyCode = repaymentPolicyCode;
    }

    public String getRepaymentPolicyName() {
        return repaymentPolicyName;
    }

    public void setRepaymentPolicyName(String repaymentPolicyName) {
        this.repaymentPolicyName = repaymentPolicyName;
    }

    public enums.RepaymentType getRepaymentType() {
        return repaymentType;
    }

    public void setRepaymentType(enums.RepaymentType repaymentType) {
        this.repaymentType = repaymentType;
    }

    public enums.RepaymentFrequency getRepaymentFrequency() {
        return repaymentFrequency;
    }

    public void setRepaymentFrequency(enums.RepaymentFrequency repaymentFrequency) {
        this.repaymentFrequency = repaymentFrequency;
    }
}
