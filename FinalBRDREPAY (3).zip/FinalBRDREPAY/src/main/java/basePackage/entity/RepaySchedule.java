package basePackage.entity;

import com.fasterxml.jackson.annotation.JsonFormat;
import org.springframework.format.annotation.DateTimeFormat;

import javax.persistence.*;
import java.sql.Date;

@Entity
@Table(name="repay_17250")
public class RepaySchedule {

//    @Id
//    @GeneratedValue(strategy = GenerationType.SEQUENCE ,generator = "idGenerator")
//    @SequenceGenerator(name ="idGenerator",initialValue =100001,allocationSize = 1)
//
    @Id
    @GeneratedValue(strategy= GenerationType.TABLE, generator="ID_TABLE_GEN_BATCH_6")
    private Long id;

    private Double effectiveInterestRate;
    private Double installmentAmount;
    private Integer installmentNumber;
    @ManyToOne(fetch = FetchType.LAZY)
    private LoanAccount loanAccount;
    private String loanApplicationId;
    private Double openingBalance;
    private Double outstandingBalancePrincipal;
    private Double principalComponent;
    private Date dueDate;
    private Double interestComponent;
    @Embedded
    private MetaData metaData;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Double getEffectiveInterestRate() {
        return effectiveInterestRate;
    }

    public void setEffectiveInterestRate(Double effectiveInterestRate) {
        this.effectiveInterestRate = effectiveInterestRate;
    }

    public Double getInstallmentAmount() {
        return installmentAmount;
    }

    public void setInstallmentAmount(Double installmentAmount) {
        this.installmentAmount = installmentAmount;
    }

    public Integer getInstallmentNumber() {
        return installmentNumber;
    }

    public void setInstallmentNumber(Integer installmentNumber) {
        this.installmentNumber = installmentNumber;
    }

    public LoanAccount getLoanAccount() {
        return loanAccount;
    }

    public void setLoanAccount(LoanAccount loanAccount) {
        this.loanAccount = loanAccount;
    }

    public String getLoanApplicationId() {
        return loanApplicationId;
    }

    public void setLoanApplicationId(String loanApplicationId) {
        this.loanApplicationId = loanApplicationId;
    }

    public Double getOpeningBalance() {
        return openingBalance;
    }

    public void setOpeningBalance(Double openingBalance) {
        this.openingBalance = openingBalance;
    }

    public Double getOutstandingBalancePrincipal() {
        return outstandingBalancePrincipal;
    }

    public void setOutstandingBalancePrincipal(Double outstandingBalancePrincipal) {
        this.outstandingBalancePrincipal = outstandingBalancePrincipal;
    }

    public Double getPrincipalComponent() {
        return principalComponent;
    }

    public void setPrincipalComponent(Double principalComponent) {
        this.principalComponent = principalComponent;
    }

    public Date getDueDate() {
        return dueDate;
    }

    public void setDueDate(Date dueDate) {
        this.dueDate = dueDate;
    }

    public Double getInterestComponent() {
        return interestComponent;
    }

    public void setInterestComponent(Double interestComponent) {
        this.interestComponent = interestComponent;
    }

    public MetaData getMetaData() {
        return metaData;
    }

    public void setMetaData(MetaData metaData) {
        this.metaData = metaData;
    }

    @Override
    public String toString() {
        return "RepaySchedule{" +
                "id=" + id +
                ", effectiveInterestRate=" + effectiveInterestRate +
                ", installmentAmount=" + installmentAmount +
                ", installmentNumber=" + installmentNumber +
                ", loanAccount=" + loanAccount +
                ", loanApplicationId='" + loanApplicationId + '\'' +
                ", openingBalance=" + openingBalance +
                ", outstandingBalancePrincipal=" + outstandingBalancePrincipal +
                ", principalComponent=" + principalComponent +
                ", dueDate=" + dueDate +
                ", interestComponent=" + interestComponent +
                ", metaData=" + metaData +
                '}';
    }
}
