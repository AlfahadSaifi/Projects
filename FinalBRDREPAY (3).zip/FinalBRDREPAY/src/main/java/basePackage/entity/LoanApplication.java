package basePackage.entity;

import javax.persistence.*;
import java.sql.Date;

@Entity
@Table(name = "LOAN_APPLICATION_TEMP_BATCH_6_17250")
public class LoanApplication{

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long loanId;
    private String loanApplicationId;
    private Date applicationCreationDate;
    private Double loanAmount;
    private Integer tenure;
    private String loanAccountNumber;

    @ManyToOne
    LoanProduct loanProduct;

    private String product;
    private String branch;

    private String productType;

    public Long getLoanId() {
        return loanId;
    }

    public void setLoanId(Long loanId) {
        this.loanId = loanId;
    }

    public String getLoanApplicationId() {
        return loanApplicationId;
    }

    public void setLoanApplicationId(String loanApplicationId) {
        this.loanApplicationId = loanApplicationId;
    }

    public Date getApplicationCreationDate() {
        return applicationCreationDate;
    }

    public void setApplicationCreationDate(Date applicationCreationDate) {
        this.applicationCreationDate = applicationCreationDate;
    }

    public Double getLoanAmount() {
        return loanAmount;
    }

    public void setLoanAmount(Double loanAmount) {
        this.loanAmount = loanAmount;
    }

    public Integer getTenure() {
        return tenure;
    }

    public void setTenure(Integer tenure) {
        this.tenure = tenure;
    }

    public String getLoanAccountNumber() {
        return loanAccountNumber;
    }

    public void setLoanAccountNumber(String loanAccountNumber) {
        this.loanAccountNumber = loanAccountNumber;
    }


    public LoanProduct getLoanProduct() {
        return loanProduct;
    }

    public void setLoanProduct(LoanProduct loanProduct) {
        this.loanProduct = loanProduct;
    }

    public String getProduct() {
        return product;
    }

    public void setProduct(String product) {
        this.product = product;
    }

    public String getProductType() {
        return productType;
    }

    public void setProductType(String productType) {
        this.productType = productType;
    }


    public String getBranch() {
        return branch;
    }

    public void setBranch(String branch) {
        this.branch = branch;
    }

    @Override
    public String toString() {
        return "LoanApplication{" +
                "loanId=" + loanId +
                ", loanApplicationId='" + loanApplicationId + '\'' +
                ", applicationCreationDate=" + applicationCreationDate +
                ", loanAmount=" + loanAmount +
                ", tenure=" + tenure +
                ", loanAccountNumber='" + loanAccountNumber + '\'' +
                ", product=" + loanProduct +
                '}';
    }
}