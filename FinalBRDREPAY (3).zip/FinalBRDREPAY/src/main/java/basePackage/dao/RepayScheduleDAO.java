package basePackage.dao;

import basePackage.entity.RepaySchedule;
import basePackage.entityDTO.RepayScheduleDTO;

import java.util.List;

public interface RepayScheduleDAO {

    void insert(List<RepaySchedule> repaySchedule);
    List<RepayScheduleDTO> fetchRepaySchedule(String loanAccountNumber);

    boolean updateLoanId(String loanApplicationId,String loanAccountNumber);
}
