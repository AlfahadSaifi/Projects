package basePackage.dao;

import basePackage.utility.EmiParameters;

public interface LoanApplicationDAO {

    EmiParameters getEmiParams(String loanApplicationId);
}
