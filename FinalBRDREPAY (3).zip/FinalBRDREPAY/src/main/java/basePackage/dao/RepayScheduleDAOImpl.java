package basePackage.dao;

import basePackage.entity.RepaySchedule;
import basePackage.entityDTO.RepayScheduleDTO;
import basePackage.factory.RepaySessionFactory;
import basePackage.utility.RepayScheduleMapper;
import org.hibernate.Session;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.List;

@Repository
public class RepayScheduleDAOImpl implements RepayScheduleDAO{


    @Override
    public void insert(List<RepaySchedule> repayScheduleList) {

        for(RepaySchedule repaySchedule:repayScheduleList) {

            try (Session session = RepaySessionFactory.getSession().openSession()) {
                session.beginTransaction();
                session.save(repaySchedule);
                System.out.println(repaySchedule);
                session.getTransaction().commit();
            }
        }
    }

    @Override
    public List<RepayScheduleDTO> fetchRepaySchedule(String loanApplicationId) {
        List<RepaySchedule> repayScheduleList=null;
        List<RepayScheduleDTO> repayScheduleDTOList= new ArrayList<>();
        try(Session session= RepaySessionFactory.getSession().openSession()) {
            repayScheduleList = session.createQuery("from RepaySchedule where loanId = :loanId", RepaySchedule.class)
                    .setParameter("loanApplicationId", loanApplicationId)
                    .getResultList();

        }catch (Exception e){
            return repayScheduleDTOList;
        }

        for(RepaySchedule repaySchedule:repayScheduleList){
            repayScheduleDTOList.add(RepayScheduleMapper.convertToDTO(repaySchedule));
        }
        return repayScheduleDTOList;
    }

    @Override
    public boolean updateLoanId(String loanApplicationId,String loanAccountNumber) {

        try (Session session = RepaySessionFactory.getSession().openSession()) {
            session.beginTransaction();
            session.createNativeQuery("update repay_17250 set loanAccountNumber=: loanAccountNumber where loanApplicationId=:loanApplicationId", RepaySchedule.class)
                    .setParameter("loanAccountNumber", loanAccountNumber)
                    .setParameter("loanApplicationId", loanApplicationId)
                    .getSingleResult();
            session.getTransaction().commit();
        }catch (Exception e){
            return false;
        }
        return true;
    }


}
