package basePackage.dao;


import basePackage.entity.LoanProduct;
import basePackage.entity.RepaymentPolicy;
import basePackage.utility.EmiParameters;
import basePackage.entity.LoanApplication;
import basePackage.factory.RepaySessionFactory;
import org.hibernate.Session;
import org.springframework.stereotype.Repository;

@Repository
public class LoanApplicationDAOImpl implements LoanApplicationDAO {

    @Override
    public EmiParameters getEmiParams(String loanApplicationId) {
        EmiParameters emiParameters=new EmiParameters();


//        emiParameters.setLoanApplicationId(loanApplicationId);
//        try(Session session= RepaySessionFactory.getSession().openSession()) {
//
//            LoanApplication loanApplication = session.createQuery("from loanApplication where loanApplicationId =:loanApplicationId", LoanApplication.class)
//                    .setParameter("loanApplicationId", loanApplicationId)
//                    .getResultList().stream().findFirst().get();
//            emiParameters.setTenure(loanApplication.getTenure());
//            emiParameters.setLoanAmount(loanApplication.getLoanAmount());
//
//            LoanProduct loanProduct= session.createQuery("from LoanProduct where productId=:productId",LoanProduct.class)
//                    .setParameter("productId",1)
//                    .getSingleResult();
//            emiParameters.setRate(loanProduct.getRateOfInterest());
//
//            RepaymentPolicy repaymentPolicy=session.createQuery("from RepaymentPolicy where productId=:productId",RepaymentPolicy.class)
//                    .setParameter("productId",1)
//                    .getSingleResult();
//
//            String repaymentType=repaymentPolicy.getRepaymentType().toString().toUpperCase();
//            switch(repaymentType){
//                case "INSTALLMENT":
//                    emiParameters.setFixedOrFloat("FIXED");
//                    break;
//                case "NONINSTALLMENT":
//                    emiParameters.setFixedOrFloat("FLOATING");
//                    break;
//
//                default:
//                    System.out.println("error");
//            }
//
//
//
//            String repaymentFrequency =repaymentPolicy.getRepaymentFrequency().toString().toUpperCase();
//
//            switch(repaymentFrequency){
//                case "QUARTERLY":
//                    emiParameters.setRepaymentFrequency(4);
//                    break;
//                case "HALF_YEARLY":
//                    emiParameters.setRepaymentFrequency(2);
//                    break;
//                case "YEARLY":
//                    emiParameters.setRepaymentFrequency(1);
//                    break;
//                case "MONTHLY":
//                    emiParameters.setRepaymentFrequency(12);
//                    break;
//
//                default:
//                    System.out.println("error");
//            }
//
//        }catch (Exception e){
//            return null;
//        }

        //Hit loanApplication table where loanApplicationId is matching
        emiParameters.setLoanAmount(123456.0);
        emiParameters.setRate(12.0);
        emiParameters.setTenure(5.0);
        emiParameters.setRepaymentFrequency(4);
        emiParameters.setLoanApplicationId(loanApplicationId);
        emiParameters.setFixedOrFloat("FIXED");

        return emiParameters;
    }
}
