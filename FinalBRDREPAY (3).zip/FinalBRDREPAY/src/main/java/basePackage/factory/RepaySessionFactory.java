package basePackage.factory;

import basePackage.entity.*;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class RepaySessionFactory {

    private RepaySessionFactory(){

    }
    private static SessionFactory sessionFactory;
    public static SessionFactory getSession(){

        if(sessionFactory==null){
            sessionFactory = new Configuration()
                    .addAnnotatedClass(RepaySchedule.class)
                    .addAnnotatedClass(LoanAccount.class)
                    .addAnnotatedClass(MetaData.class)
                    .addAnnotatedClass(LoanApplication.class)
                    .addAnnotatedClass(LoanProduct.class)
                    .configure()
                    .buildSessionFactory();
        }

        return sessionFactory;
    }

}
