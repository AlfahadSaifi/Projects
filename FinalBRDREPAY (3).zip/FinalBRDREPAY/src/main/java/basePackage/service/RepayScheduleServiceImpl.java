package basePackage.service;

import basePackage.dao.RepayScheduleDAO;
import basePackage.entityDTO.RepayScheduleDTO;
import basePackage.utility.EmiParameters;
import basePackage.utility.EmiUtility;
import basePackage.entity.RepaySchedule;
import basePackage.utility.RepayScheduleMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class RepayScheduleServiceImpl implements RepayScheduleService {

    @Autowired
    RepayScheduleDAO repayScheduleDAO;
    @Autowired
    LoanApplicationService loanApplicationService;
    @Autowired
    EmiUtility emiUtility;

    @Override
    public List<RepayScheduleDTO> insert(String loanApplicationId) {
        EmiParameters emiParameters= loanApplicationService.getEmiParams(loanApplicationId);
        List<RepaySchedule> repayScheduleList;
        if(emiParameters.getFixedOrFloat().equalsIgnoreCase("FIXED"))
            repayScheduleList=emiUtility.generateRepayScheduleForFixedRate(emiParameters.getLoanAmount(),emiParameters.getTenure(),emiParameters.getRepaymentFrequency(),emiParameters.getRate());
        else
            repayScheduleList=emiUtility.generateRepayScheduleForFloatingRate(emiParameters.getLoanAmount(),emiParameters.getTenure(),emiParameters.getRepaymentFrequency(),emiParameters.getRate());

        repayScheduleList.forEach((repaySchedule)->{repaySchedule.setLoanApplicationId(loanApplicationId);});
        repayScheduleDAO.insert(repayScheduleList);


        List<RepayScheduleDTO> repayListForUser= new ArrayList<>();

        for(RepaySchedule repaySchedule:repayScheduleList){

            repayListForUser.add(RepayScheduleMapper.convertToDTO(repaySchedule));

        }
        return repayListForUser;
    }

    @Override
    public List<RepayScheduleDTO> fetchRepaySchedule(String loanApplicationId) {
        return repayScheduleDAO.fetchRepaySchedule(loanApplicationId);
    }

    @Override
    public boolean updateLoanId(String loanApplicationId,String loanAccountNumber){
        return repayScheduleDAO.updateLoanId(loanApplicationId,loanAccountNumber);
    }
}
