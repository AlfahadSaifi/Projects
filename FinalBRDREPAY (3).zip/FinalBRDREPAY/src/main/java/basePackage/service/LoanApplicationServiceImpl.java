package basePackage.service;

import basePackage.dao.LoanApplicationDAO;
import basePackage.utility.EmiParameters;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class LoanApplicationServiceImpl implements LoanApplicationService {
    @Autowired
    LoanApplicationDAO loanApplicationDAO;
    @Override
    public EmiParameters getEmiParams(String loanApplicationId) {
        return loanApplicationDAO.getEmiParams(loanApplicationId);
    }
}
