package basePackage.service;

import basePackage.utility.EmiParameters;

public interface LoanApplicationService {

    EmiParameters getEmiParams(String loanApplicationId);
}
