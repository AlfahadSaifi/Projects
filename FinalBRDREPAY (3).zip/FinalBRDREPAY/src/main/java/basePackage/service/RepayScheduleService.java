package basePackage.service;

import basePackage.entity.RepaySchedule;
import basePackage.entityDTO.RepayScheduleDTO;

import java.util.List;

public interface RepayScheduleService {

    List<RepayScheduleDTO> insert(String loanApplicationId);
    List<RepayScheduleDTO> fetchRepaySchedule(String loanApplicationNumber);

    boolean updateLoanId(String loanApplicationId,String loanAccountNumber);


}
