package basePackage.restcontrollers;


import basePackage.entity.RepaySchedule;
import basePackage.entityDTO.RepayScheduleDTO;
import basePackage.service.RepayScheduleService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
public class RepayScheduleController {

    @Autowired
    RepayScheduleService repayScheduleService;

    @PostMapping(value = "getRepay.do", produces = MediaType.APPLICATION_JSON_VALUE)
    public List<RepayScheduleDTO> getRepay(@RequestParam("loanApplicationId") String loanApplicationId) {
        return repayScheduleService.insert(loanApplicationId);
    }

}