package basePackage.utility;
import basePackage.entity.RepaySchedule;
import basePackage.entityDTO.RepayScheduleDTO;

public class RepayScheduleMapper {

    public static RepayScheduleDTO convertToDTO(RepaySchedule repaySchedule) {
        RepayScheduleDTO repayScheduleDTO= new RepayScheduleDTO();
        repayScheduleDTO.setInstallmentAmount(repaySchedule.getInstallmentAmount());
        repayScheduleDTO.setDueDate(repaySchedule.getDueDate());
        repayScheduleDTO.setEffectiveInterestRate(repaySchedule.getEffectiveInterestRate());
        repayScheduleDTO.setInterestComponent(repaySchedule.getInterestComponent());
        repayScheduleDTO.setPrincipalComponent(repaySchedule.getPrincipalComponent());
        repayScheduleDTO.setOpeningBalance(repaySchedule.getOpeningBalance());
        repayScheduleDTO.setInstallmentNumber(repaySchedule.getInstallmentNumber());
        repayScheduleDTO.setOutstandingBalancePrincipal(repaySchedule.getOutstandingBalancePrincipal());

        return repayScheduleDTO;
    }
}