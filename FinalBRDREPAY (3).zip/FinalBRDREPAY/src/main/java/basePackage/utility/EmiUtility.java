package basePackage.utility;

import basePackage.entity.RepaySchedule;
import basePackage.entityDTO.RepayScheduleDTO;
import org.apache.log4j.Logger;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.sql.Date;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

@Component
public class EmiUtility {

    private static final Logger logger = Logger.getLogger("mylogs");

    private Double calculateEMI(double loanAmount, double tenure, int repaymentFrequency, double roi) {
        int installments = repaymentFrequency;
        double rv = 0;
        double rate = roi / (installments * 100);
        double totalInstallments = tenure * installments;
        double exp = Math.pow(1 + rate, totalInstallments);
        return (loanAmount * rate - (rv * rate) / exp) / (1 - 1 / exp);
    }


    public List<RepaySchedule> generateRepayScheduleForFixedRate(Double loanAmount, Double tenure, Integer repaymentFrequency, Double rate) {
        List<RepaySchedule> repayScheduleList = new ArrayList<>();
        double newRate=rate;
        double interestComponent;
        double principalComponent;
        double outstandingPrincipal;
        double principal = loanAmount;

        double installmentAmount = calculateEMI(loanAmount, tenure, repaymentFrequency, rate);

        int installments = repaymentFrequency;
        rate = rate / (installments * 100);

        double totalInstallments = tenure * installments;

        for (int installmentNo = 1; installmentNo < totalInstallments + 1; installmentNo++) {
            RepaySchedule repaySchedule= new RepaySchedule();
            interestComponent = principal * rate;
            principalComponent = installmentAmount - interestComponent;
            outstandingPrincipal = principal - principalComponent;


            repaySchedule.setOpeningBalance(Math.round(principal * 100.0) / 100.0);
            repaySchedule.setId((long) (installmentNo));
            repaySchedule.setInstallmentNumber(installmentNo);
            repaySchedule.setDueDate(Date.valueOf(LocalDate.of(2024, 1, 1).plusMonths(installmentNo + 1)));
            repaySchedule.setInterestComponent(Math.round(interestComponent * 100.0) / 100.0);
            repaySchedule.setInstallmentAmount(Math.round(installmentAmount * 100.0) / 100.0);
            repaySchedule.setPrincipalComponent(Math.round(principalComponent * 100.0) / 100.0);
            repaySchedule.setOutstandingBalancePrincipal((Math.round(outstandingPrincipal * 100.0) / 100.0)<0 ?0.0:Math.round(outstandingPrincipal * 100.0) / 100.0);
            repaySchedule.setEffectiveInterestRate(rate);

            repayScheduleList.add(repaySchedule);

            principal = outstandingPrincipal;
        }

        return repayScheduleList;
    }

    public List<RepaySchedule> generateRepayScheduleForFloatingRate(Double loanAmount, Double tenure, Integer repaymentFrequency, Double rate) {
        List<RepaySchedule> repayScheduleList = new ArrayList<>();
        double newRate=rate;
        double interestComponent;
        double principalComponent;
        double outstandingPrincipal=1;
        double principal = loanAmount;
        LocalDate startDate = LocalDate.of(2024, 1, 1);

        double installmentAmount = calculateEMI(loanAmount, tenure, repaymentFrequency, rate);

        int installments = repaymentFrequency;
        rate = rate / (installments * 100);

        double totalInstallments = tenure * installments;

        int installmentNo = 1;

        while(outstandingPrincipal>0){
            RepaySchedule repaySchedule= new RepaySchedule();
            interestComponent = principal * rate;
            principalComponent = installmentAmount - interestComponent;
            outstandingPrincipal = principal - principalComponent;


            if(installmentNo==totalInstallments/2){
                rate=newRate+10;
                rate=rate / (installments * 100);
                installmentAmount = calculateEMI(principal, tenure/2, repaymentFrequency, rate);
            }

            repaySchedule.setOpeningBalance(Math.round(principal * 100.0) / 100.0);
            repaySchedule.setId((long) (installmentNo));
            repaySchedule.setInstallmentNumber(installmentNo);
             // Calculate due date
            LocalDate dueDate=startDate;
            startDate = startDate.plusMonths(repaymentFrequency);
            repaySchedule.setDueDate(Date.valueOf(dueDate));
            repaySchedule.setInterestComponent(Math.round(interestComponent * 100.0) / 100.0);
            repaySchedule.setInstallmentAmount(Math.round(installmentAmount * 100.0) / 100.0);
            repaySchedule.setPrincipalComponent(Math.round(principalComponent * 100.0) / 100.0);
            repaySchedule.setOutstandingBalancePrincipal((Math.round(outstandingPrincipal * 100.0) / 100.0)<0 ?0.0:Math.round(outstandingPrincipal * 100.0) / 100.0);
            repaySchedule.setEffectiveInterestRate(rate);
            repayScheduleList.add(repaySchedule);

            installmentNo++;
            principal = outstandingPrincipal;
        }

        return repayScheduleList;
    }
}

