package basePackage.utility;

public class enums {

    public enum RepaymentFrequency {
        MONTHLY , YEARLY , HALF_YEARLY , QUARTERLY
    }

    public enum RepaymentType{
        INSTALLMENT , NONINSTALLMENT
    }
}
